#!/system/bin/sh
# PrimeThermal-OneUI v1.1
# Dual-sensor logic: Battery/Case (primary) + CPU Cores (emergency)

LOG="/data/local/tmp/s10_thermal.log"
ERR="/data/local/tmp/s10_thermal.err"

mkdir -p /data/local/tmp
echo "[INIT] v1.1-OneUI started $(date) PID=$$" > "$LOG"

(
  LOG="/data/local/tmp/s10_thermal.log"
  ERR="/data/local/tmp/s10_thermal.err"
  BATT="/sys/class/power_supply/battery/status"
  SWAP="/proc/sys/vm/swappiness"
  COMPACT="/proc/sys/vm/compact_memory"

  POL0="/sys/devices/system/cpu/cpufreq/policy0"
  POL4="/sys/devices/system/cpu/cpufreq/policy4"
  POL6="/sys/devices/system/cpu/cpufreq/policy6"

  # Датчики: Skin (primary) + CPU Cores (emergency)
  T_SKIN="/sys/class/thermal/thermal_zone5/temp"
  T_BATT="/sys/class/thermal/thermal_zone6/temp"
  T_CORE0="/sys/class/thermal/thermal_zone0/temp"
  T_CORE1="/sys/class/thermal/thermal_zone1/temp"
  T_CORE2="/sys/class/thermal/thermal_zone2/temp"

  M0=1950000; M4=2314000; M6=2730000
  ST="ACTIVE"; LC=0; DB=15; L1=0; L2=0; L3=0; HC=0

  rotate_log() {
    if [ -f "$LOG" ]; then
      lines=$(wc -l < "$LOG" 2>/dev/null | tr -d ' ')
      if [ "$lines" -gt 1000 ] 2>/dev/null; then
        tail -n 1000 "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG" 2>/dev/null
        echo "[SYS] Log rotated" >> "$LOG" 2>/dev/null
      fi
    fi
  }

  # Читаем температуру кожи (батарея или платформа)
  get_skin_t() {
    v=$(cat "$T_SKIN" 2>/dev/null)
    if [ -z "$v" ] || [ "$v" = "0" ]; then
      v=$(cat "$T_BATT" 2>/dev/null)
    fi
    v=${v:-0}
    [ "$v" -gt 1000 ] 2>/dev/null && v=$((v/1000))
    echo "$v"  }

  # Читаем максимальную температуру ядер
  get_core_t() {
    t1=$(cat "$T_CORE0" 2>/dev/null); t1=${t1:-0}
    t2=$(cat "$T_CORE1" 2>/dev/null); t2=${t2:-0}
    t3=$(cat "$T_CORE2" 2>/dev/null); t3=${t3:-0}
    [ "$t1" -gt 1000 ] 2>/dev/null && t1=$((t1/1000))
    [ "$t2" -gt 1000 ] 2>/dev/null && t2=$((t2/1000))
    [ "$t3" -gt 1000 ] 2>/dev/null && t3=$((t3/1000))
    max=$t1
    [ "$t2" -gt "$max" ] 2>/dev/null && max=$t2
    [ "$t3" -gt "$max" ] 2>/dev/null && max=$t3
    echo "$max"
  }

  is_off() {
    dumpsys power 2>/dev/null | grep -q "Display Power: state=OFF" && return 0
    dumpsys window 2>/dev/null | grep -q "mScreenOnFully=false" && return 0
    return 1
  }

  apply_tweaks() {
    case "$1" in
      POCKET|IDLE)
        for p in $POL0 $POL4 $POL6; do
          echo 2000 > "$p/schedutil/up_rate_limit_us" 2>/dev/null
          echo 10000 > "$p/schedutil/down_rate_limit_us" 2>/dev/null
        done
        [ -f "$SWAP" ] && echo 100 > "$SWAP" 2>/dev/null
        [ -f "$COMPACT" ] && echo 1 > "$COMPACT" 2>/dev/null
        echo "[TWEAKS] ECO applied" >> "$LOG" 2>/dev/null
        ;;
      LIGHT)
        for p in $POL0 $POL4 $POL6; do
          echo 1000 > "$p/schedutil/up_rate_limit_us" 2>/dev/null
          echo 5000 > "$p/schedutil/down_rate_limit_us" 2>/dev/null
        done
        [ -f "$SWAP" ] && echo 60 > "$SWAP" 2>/dev/null
        [ -f "$COMPACT" ] && echo 1 > "$COMPACT" 2>/dev/null
        echo "[TWEAKS] BALANCED applied" >> "$LOG" 2>/dev/null
        ;;
      ACTIVE|CHARGING)
        for p in $POL0 $POL4 $POL6; do
          echo 500 > "$p/schedutil/up_rate_limit_us" 2>/dev/null
          echo 2000 > "$p/schedutil/down_rate_limit_us" 2>/dev/null
        done
        [ -f "$SWAP" ] && echo 10 > "$SWAP" 2>/dev/null
        [ -f "$COMPACT" ] && echo 1 > "$COMPACT" 2>/dev/null
        echo "[TWEAKS] PERF applied" >> "$LOG" 2>/dev/null        ;;
    esac
  }

  echo "[INIT] Entering main loop" >> "$LOG" 2>/dev/null

  while true; do
    SKIN_T=$(get_skin_t)
    CORE_T=$(get_core_t)
    
    # Используем максимальную из двух, но приоритет на SKIN
    T=$SKIN_T
    [ "$CORE_T" -gt "$T" ] 2>/dev/null && T=$CORE_T

    read _ u1 n1 s1 i1 w1 q1 sq1 st1 _ < /proc/stat 2>/dev/null
    sleep 1
    read _ u2 n2 s2 i2 w2 q2 sq2 st2 _ < /proc/stat 2>/dev/null
    t1=$((u1+n1+s1+i1+w1+q1+sq1+st1))
    t2=$((u2+n2+s2+i2+w2+q2+sq2+st2))
    dt=$((t2-t1)); di=$((i2-i1))
    IL=0; [ "$dt" -gt 0 ] 2>/dev/null && IL=$(((dt-di)*100/dt))
    L1=$L2; L2=$L3; L3=$IL
    AVG=$(((L1+L2+L3)/3))

    [ "$T" -ge 40 ] 2>/dev/null && HC=$((HC+1)) || HC=0

    BT=$(cat "$BATT" 2>/dev/null)
    OFF=false; is_off && OFF=true
    NW=$(date +%s 2>/dev/null)
    
    # ДВОЙНАЯ ЛОГИКА:
    # 1. Если ядра > 45°C → ACTIVE (экстренное охлаждение)
    # 2. Иначе смотрим на температуру корпуса (SKIN_T)
    TG="ACTIVE"
    
    if [ "$OFF" = true ]; then
      TG="POCKET"
    elif [ "$BT" = "Charging" ] && [ "$SKIN_T" -ge 38 ] 2>/dev/null; then
      TG="CHARGING"
    elif [ "$CORE_T" -ge 45 ] 2>/dev/null; then
      TG="ACTIVE"
    elif [ "$SKIN_T" -ge 41 ] 2>/dev/null; then
      TG="ACTIVE"
    elif [ "$SKIN_T" -ge 37 ] 2>/dev/null; then
      TG="LIGHT"
    elif [ "$AVG" -ge 40 ] 2>/dev/null; then
      TG="ACTIVE"
    elif [ "$AVG" -ge 15 ] 2>/dev/null; then
      TG="LIGHT"
    else      TG="IDLE"
    fi

    if [ "$TG" != "$ST" ]; then
      if [ $((NW - LC)) -ge "$DB" ] 2>/dev/null; then
        echo "[STATE] $ST -> $TG (Skin=${SKIN_T}C Core=${CORE_T}C L=$AVG%)" >> "$LOG" 2>/dev/null
        ST="$TG"; LC=$NW
        apply_tweaks "$ST"
        rotate_log
      fi
    fi

    F0=$M0; F4=$M4; F6=$M6
    case "$ST" in
      POCKET) F0=600000; F4=600000; F6=600000 ;;
      CHARGING) F0=$((M0/2)); F4=$((M4/2)); F6=$((M6*40/100)) ;;
      IDLE) F0=1000000; F4=900000; F6=700000 ;;
      LIGHT) F0=1300000; F4=1500000; F6=1700000 ;;
      ACTIVE)
        if [ "$HC" -ge 2 ] 2>/dev/null; then
          if [ "$T" -ge 44 ] 2>/dev/null; then F0=$((M0/2)); F4=$((M4/2)); F6=$((M6/2))
          elif [ "$T" -ge 42 ] 2>/dev/null; then F0=$((M0*65/100)); F4=$((M4*65/100)); F6=$((M6*65/100))
          elif [ "$T" -ge 40 ] 2>/dev/null; then F0=$((M0*80/100)); F4=$((M4*80/100)); F6=$((M6*80/100))
          fi
        fi ;;
    esac

    echo $F0 > "$POL0/scaling_max_freq" 2>/dev/null
    echo $F4 > "$POL4/scaling_max_freq" 2>/dev/null
    echo $F6 > "$POL6/scaling_max_freq" 2>/dev/null

    echo "[$(date +%H:%M:%S)] $ST Skin=${SKIN_T}C Core=${CORE_T}C H=$HC L=${AVG}% F6=$F6" >> "$LOG" 2>/dev/null
    sleep 4
  done
) > /dev/null 2>"$ERR" &

exit 0